# ChangeLogs

## `v1.0.3`

- fix: run button shown on runners terminal tab
- feat: add `luau` support

## `v1.0.2`

- fix: play button issue
- reduce useless stuffs logging when running program

## `v1.0.1`

- fix: c and c++ compiler stuff

# ChangeLogs

## `v1.0.1`

- fix: c and c++ compiler stuff

## `v1.0.2`

- fix: play button issue
- reduce useless stuffs logging when running program